
class ErrorModel{

 String text;
 bool hasError;

 ErrorModel({required this.text,required this.hasError});

}