class MyLanguageModel {
  String languageName;
  String languageCode;
  String countryCode;

  MyLanguageModel({required this.languageName, required this.countryCode, required this.languageCode});
}
