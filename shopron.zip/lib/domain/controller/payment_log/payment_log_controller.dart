import 'package:get/get.dart';

class PaymentLogController extends GetxController{

  double paymentAmount = 599.6;
  int productSize = 6;

  String transectionId = "DW2458967847874";

}