import 'package:get/get.dart';

class TrackOrderController extends GetxController{

  bool isConfirmed = true;

}