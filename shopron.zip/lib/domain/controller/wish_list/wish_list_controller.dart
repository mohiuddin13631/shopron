import 'package:get/get.dart';

class WishListController extends GetxController{

  double productPrice = 220.00;

  int totalRating = 214;

}