import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MyReviewController extends GetxController{

  TextEditingController reviewController = TextEditingController();
  FocusNode reviewFocusNode = FocusNode();

}