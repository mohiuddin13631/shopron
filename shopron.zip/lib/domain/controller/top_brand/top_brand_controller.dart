import 'package:get/get.dart';

class TopBrandController extends GetxController{

}