package com.example.shopron

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
